% Pascal_Lehmann_P2_Pr=Octave
% DGL (2)
function [bild_2] = f_2(x)

bild_2 = 10*sin(x)-10*cos(5*x);

endfunction
