% Pascal_Lehmann_P2_Pr=Octave
% DGL (1)
function [bild_1] = f_1(beta,y) 
  
  bild_1 = beta*(1-y)*y;
  
endfunction
